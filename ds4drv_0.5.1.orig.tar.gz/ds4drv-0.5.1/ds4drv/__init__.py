"""ds4drv is a Sony DualShock 4 userspace driver for Linux."""

__title__ = "ds4drv"
__version__ = "0.5.1"
__author__ = "Christopher Rosell"
__credits__ = ["Christopher Rosell", "George Gibbs", "Lauri Niskanen"]
__license__ = "MIT"
